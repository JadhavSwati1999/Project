# HR-Management-System.
Deploying the HR Management System using AWS Services.

